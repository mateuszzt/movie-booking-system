"""
Test logiki BEZ otwierania portow (srodowisko blokuje bind socketow).
- Reservation testujemy przez Starlette TestClient (in-memory ASGI, bez portu).
- Wywolanie HTTP do Payment podmieniamy (monkeypatch) tak, by:
    * w trybie normalnym wywolac realna funkcje payment_service.pay()  (prawdziwa logika modulu platnosci),
    * w trybie awarii rzucic httpx.ConnectError (symulacja padnietego modulu).
Dzieki temu testujemy realna logike obu modulow i obsluge bledow.
"""
import os, sys, time, types

os.environ["LOCK_SECONDS"] = "2"
os.environ["PAYMENT_TIMEOUT"] = "3"
os.environ["FAILURE_RATE"] = "0"
os.environ["MAX_DELAY"] = "0.05"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "reservation"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "payment"))

import httpx
import reservation_service as R
import payment_service as P

PAYMENT_DOWN = {"v": False}   # przelacznik "awaria modulu platnosci"

# --- Podmiana klienta HTTP w module rezerwacji ---
class FakeResponse:
    def __init__(self, data): self._data = data
    def raise_for_status(self): pass
    def json(self): return self._data

class FakeAsyncClient:
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def post(self, url, json=None):
        if PAYMENT_DOWN["v"]:
            # symulacja: modul platnosci nie odpowiada
            raise httpx.ConnectError("Connection refused")
        # realne wywolanie logiki modulu platnosci (ten sam kod co w usludze)
        req = P.PaymentRequest(**json)
        resp = P.pay(req)              # prawdziwa funkcja /pay
        return FakeResponse(resp.model_dump())

R.httpx.AsyncClient = FakeAsyncClient   # monkeypatch

from fastapi.testclient import TestClient

results = []
def check(name, cond, detail=""):
    results.append(bool(cond))
    print(f"[{'OK' if cond else 'FAIL'}] {name}" + (f" -> {detail}" if detail else ""))

with TestClient(R.app) as c:           # uruchamia worker auto-anulowania (lifespan)
    check("Oba moduly zaladowane (reservation+payment)", True)
    check("GUI serwowane przez modul rezerwacji", "Rezerwacja" in c.get("/").text)

    # S1: lock + udana platnosc
    r = c.post("/lock", json={"seat_id": "A1"}).json()
    rid = r.get("reservation_id")
    check("S1a lock A1", r.get("ok"), f"rezerwacja={rid}")
    p = c.post("/pay", json={"reservation_id": rid}).json()
    check("S1b platnosc OK -> miejsce sprzedane", p.get("ok") and p.get("transaction_id"),
          f"tx={p.get('transaction_id')}")
    sold = next(s for s in R.SEATS.values() if s.id == "A1")
    check("S1c stan miejsca = sold", sold.status == "sold")

    # S2: podwojna blokada
    c.post("/lock", json={"seat_id": "B2"})
    dup = c.post("/lock", json={"seat_id": "B2"}).json()
    check("S2 podwojna blokada B2 odrzucona", not dup.get("ok"), dup.get("error"))

    # S2-cancel: ANULUJ -> /release natychmiast zwalnia miejsce
    rc = c.post("/lock", json={"seat_id": "A6"}).json()
    a6 = next(s for s in R.SEATS.values() if s.id == "A6")
    check("S2-cancel a: A6 zablokowane", a6.status == "locked")
    rel = c.post("/release", json={"reservation_id": rc["reservation_id"]}).json()
    check("S2-cancel b: /release zwraca ok", rel.get("ok"))
    check("S2-cancel c: A6 znowu wolne od razu (bez czekania 10 min)", a6.status == "free")
    # ponowne zwolnienie tej samej (juz zwolnionej) rezerwacji nie wywala bledu
    rel2 = c.post("/release", json={"reservation_id": rc["reservation_id"]}).json()
    check("S2-cancel d: powtorne /release jest bezpieczne", rel2.get("ok"))
    # zwolnionego miejsca nie da sie omylkowo 'sprzedac' stara rezerwacja
    paid_after_release = c.post("/pay", json={"reservation_id": rc["reservation_id"]}).json()
    check("S2-cancel e: platnosc po anulowaniu odrzucona", not paid_after_release.get("ok"))

    # S2b: platnosc za odrzucona karte -> miejsce zwolnione
    P.FAILURE_RATE = 1.0     # wymuszamy odrzucenie
    rr = c.post("/lock", json={"seat_id": "B3"}).json()
    pp = c.post("/pay", json={"reservation_id": rr["reservation_id"]}).json()
    check("S2b platnosc odrzucona przez bank", not pp.get("ok"), pp.get("error"))
    freed = next(s for s in R.SEATS.values() if s.id == "B3")
    check("S2c miejsce B3 zwolnione po odrzuceniu", freed.status == "free")
    P.FAILURE_RATE = 0.0

    # S3: auto-anulowanie po wygasnieciu blokady
    # (logika workera testowana osobno w test_expiry.py - tutaj TestClient
    #  blokuje petle async przez time.sleep, wiec pomijamy by nie dawac falszywego FAIL)
    print("[..] S3 (auto-anulowanie) -> patrz osobny test: test_expiry.py")

    # S4: AWARIA modulu platnosci
    PAYMENT_DOWN["v"] = True
    r4 = c.post("/lock", json={"seat_id": "D4"}).json()
    rid4 = r4["reservation_id"]
    fail = c.post("/pay", json={"reservation_id": rid4}).json()
    ok_fail = (not fail.get("ok")) and (
        "platnosci" in fail.get("error","").lower()
        or "niedostepny" in fail.get("error","").lower())
    check("S4a awaria platnosci wykryta przez rezerwacje", ok_fail, fail.get("error"))
    d4 = next(s for s in R.SEATS.values() if s.id == "D4")
    check("S4b blokada D4 nadal wazna (graceful degradation)", d4.status == "locked")

print(f"\n=== WYNIK: {'PASS' if all(results) else 'FAIL'} "
      f"({sum(results)}/{len(results)} testow) ===")
os._exit(0 if all(results) else 1)
