import os
import random
import time
import asyncio
import logging
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [PAYMENT] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("payment")

FAILURE_RATE = float(os.getenv("FAILURE_RATE", "0.25"))
MAX_DELAY = float(os.getenv("MAX_DELAY", "1.5"))
# Adres modulu rezerwacji - Payment pinguje go w tle, by wykryc jego awarie.
RESERVATION_URL = os.getenv("RESERVATION_URL", "http://localhost:3000")
HEALTHCHECK_INTERVAL = float(os.getenv("HEALTHCHECK_INTERVAL", "5"))


# --- Monitorowanie modulu rezerwacji (reakcja na utrate polaczenia) ---
async def reservation_monitor():
    """Co kilka sekund sprawdza, czy modul REZERWACJI zyje.
       Dzieki temu awaria jest wykrywana OBUSTRONNIE - nie tylko
       rezerwacja widzi padniecie platnosci, ale i platnosc widzi
       padniecie rezerwacji i sygnalizuje to w konsoli."""
    reservation_up = True   # zakladamy ze na starcie jest OK
    while True:
        await asyncio.sleep(HEALTHCHECK_INTERVAL)
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                r = await client.get(f"{RESERVATION_URL}/health")
                ok = r.status_code == 200
        except Exception:
            ok = False

        if not ok and reservation_up:
            log.warning("!! Utracono polaczenie z modulem REZERWACJI "
                        f"({RESERVATION_URL}) - czekam na powrot...")
            reservation_up = False
        elif ok and not reservation_up:
            log.info("Polaczenie z modulem REZERWACJI przywrocone.")
            reservation_up = True


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(reservation_monitor())
    log.info(f"Monitor modulu rezerwacji wystartowal ({RESERVATION_URL}).")
    yield
    task.cancel()


app = FastAPI(title="Payment Service", lifespan=lifespan)


class PaymentRequest(BaseModel):
    reservation_id: str
    seat: str
    amount: float
    card_number: str = "0000"


class PaymentResponse(BaseModel):
    status: str
    transaction_id: str | None = None
    reason: str | None = None


@app.get("/health")
def health():
    return {"status": "ok", "service": "payment"}


@app.post("/pay", response_model=PaymentResponse)
def pay(req: PaymentRequest):
    log.info(f"Zadanie platnosci: rezerwacja={req.reservation_id} "
             f"miejsce={req.seat} kwota={req.amount} zl")
    time.sleep(random.uniform(0.2, MAX_DELAY))   # symulacja pracy bramki

    if random.random() < FAILURE_RATE:
        reason = random.choice([
            "Brak srodkow na koncie",
            "Karta odrzucona przez bank",
            "Przekroczono limit transakcji",
            "Blad autoryzacji 3D-Secure",
        ])
        log.warning(f"  -> PLATNOSC ODRZUCONA: {reason}")
        return PaymentResponse(status="failed", reason=reason)

    tx = f"TX-{random.randint(100000, 999999)}"
    log.info(f"  -> PLATNOSC OK, transakcja={tx}")
    return PaymentResponse(status="success", transaction_id=tx)


if __name__ == "__main__":
    port = int(os.getenv("PAYMENT_PORT", "4000"))
    print("=" * 55)
    print("  PAYMENT SERVICE (modul platnosci)")
    print(f"  Nasluchuje na: http://0.0.0.0:{port}")
    print(f"  Szansa na blad platnosci: {FAILURE_RATE*100:.0f}%")
    print("=" * 55)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")
