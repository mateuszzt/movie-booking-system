"""
Test SAMEJ logiki auto-anulowania blokad (expiry_worker) w realnej petli asyncio.
Nie otwiera portow. Sprawdza, ze po uplywie LOCK_SECONDS miejsce wraca do 'free'.
"""
import os, sys, asyncio, time
os.environ["LOCK_SECONDS"] = "1"
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "reservation"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "payment"))
import reservation_service as R

async def main():
    # wystartuj worker recznie
    worker = asyncio.create_task(R.expiry_worker())

    seat = R.SEATS["C3"]
    async with R.state_lock:
        seat.status = "locked"
        seat.reservation_id = "test123"
        seat.locked_until = time.time() + 1   # wygasa za 1s
    print(f"[..] C3 zablokowane, status={seat.status}, czekam 1.8s na auto-anulowanie...")

    await asyncio.sleep(1.8)   # nieblokujace - worker dziala w tej samej petli

    ok1 = seat.status == "free"
    ok2 = seat.reservation_id is None
    print(f"[{'OK' if ok1 else 'FAIL'}] po wygasnieciu status == 'free' (jest '{seat.status}')")
    print(f"[{'OK' if ok2 else 'FAIL'}] rezerwacja wyczyszczona (jest {seat.reservation_id})")

    worker.cancel()
    print(f"\n=== EXPIRY WORKER: {'PASS' if ok1 and ok2 else 'FAIL'} ===")
    return ok1 and ok2

ok = asyncio.run(main())
os._exit(0 if ok else 1)
