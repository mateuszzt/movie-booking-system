@echo off
REM Uruchamia oba moduly (Windows). Kazdy w osobnym oknie, zna adres drugiego.
cd /d "%~dp0"
pip install -q -r requirements.txt
echo Uruchamiam Payment Service (port 4000)...
start "Payment Service" cmd /k "set RESERVATION_URL=http://localhost:3000 && python payment\payment_service.py"
timeout /t 2 >nul
echo Uruchamiam Reservation Service (port 3000)...
start "Reservation Service" cmd /k "set PAYMENT_URL=http://localhost:4000 && python reservation\reservation_service.py"
echo.
echo ================================================================
echo   System dziala!  Przegladarka:  http://localhost:3000
echo   Telefon (ta sama Wi-Fi):  http://TWOJE_IP:3000  (ipconfig)
echo ================================================================
