"""
Test OBUSTRONNEJ reakcji na utrate polaczenia.
Sprawdza monitor w module PLATNOSCI, ktory pinguje modul rezerwacji.
Podmieniamy httpx.AsyncClient, by symulowac: rezerwacja dziala -> pada -> wraca.
Bez otwierania portow.
"""
import os, sys, asyncio
os.environ["HEALTHCHECK_INTERVAL"] = "0.1"   # szybkie tetno do testu
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "payment"))
import httpx
import payment_service as P

# Stan symulowanej rezerwacji: True=dziala, False=padla
RESERVATION_ALIVE = {"v": True}
# Zbieramy logi ostrzezen/info zamiast wypisywac
events = []

class FakeResp:
    status_code = 200

class FakeClient:
    def __init__(self, *a, **k): pass
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def get(self, url):
        if RESERVATION_ALIVE["v"]:
            return FakeResp()
        raise httpx.ConnectError("refused")

P.httpx.AsyncClient = FakeClient

# Przechwytujemy logi monitora
class Collector(__import__("logging").Handler):
    def emit(self, record):
        events.append((record.levelname, record.getMessage()))
P.log.addHandler(Collector())

async def main():
    task = asyncio.create_task(P.reservation_monitor())
    await asyncio.sleep(0.25)          # kilka pingow - rezerwacja zyje (cisza)
    RESERVATION_ALIVE["v"] = False     # AWARIA rezerwacji
    await asyncio.sleep(0.3)           # monitor powinien wykryc i ostrzec
    RESERVATION_ALIVE["v"] = True      # rezerwacja wraca
    await asyncio.sleep(0.3)           # monitor powinien zglosic powrot
    task.cancel()

    warned = any(lvl == "WARNING" and "Utracono polaczenie" in msg for lvl, msg in events)
    recovered = any(lvl == "INFO" and "przywrocone" in msg for lvl, msg in events)
    print(f"[{'OK' if warned else 'FAIL'}] Platnosc wykryla AWARIE rezerwacji")
    print(f"[{'OK' if recovered else 'FAIL'}] Platnosc wykryla POWROT rezerwacji")
    print("\n=== MONITOR PLATNOSCI: " + ("PASS" if warned and recovered else "FAIL") + " ===")
    return warned and recovered

ok = asyncio.run(main())
os._exit(0 if ok else 1)
