"""GUI modulu rezerwacji - osobny plik dla czytelnosci."""

HTML_PAGE = r"""
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kino - Rezerwacja biletow</title>
<style>
  * { box-sizing: border-box; }
  body {
    font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
    background: #14161c; color: #e8eaf0; margin: 0; padding: 16px;
  }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .sub { color: #8b90a0; font-size: 13px; margin-bottom: 16px; }
  .screen {
    background: linear-gradient(#3a3f55, #20232f);
    height: 26px; border-radius: 4px; text-align: center;
    color: #b9bed0; font-size: 12px; line-height: 26px; letter-spacing: 4px;
    max-width: 420px; margin: 0 auto 22px;
  }
  .grid { display: grid; gap: 10px; max-width: 420px; margin: 0 auto; }
  .row { display: flex; gap: 10px; align-items: center; justify-content: center; }
  .rowlabel { width: 18px; color: #6b7080; font-size: 13px; }
  .seat {
    width: 46px; height: 46px; border-radius: 8px; border: none;
    font-size: 13px; font-weight: 600; cursor: pointer; color: #fff;
    transition: transform .08s;
  }
  .seat:active { transform: scale(.92); }
  .free   { background: #2e7d46; }
  .free:hover { background: #389a55; }
  .locked { background: #c9821a; cursor: not-allowed; }
  .sold   { background: #3a3f4b; color: #777; cursor: not-allowed; }
  .mine   { outline: 3px solid #5b8cff; }
  .legend { display: flex; gap: 16px; justify-content: center; margin: 20px 0; font-size: 13px; }
  .legend span { display: inline-flex; align-items: center; gap: 6px; }
  .dot { width: 14px; height: 14px; border-radius: 3px; display: inline-block; }
  #status {
    text-align: center; font-size: 13px; margin: 10px 0; min-height: 18px;
  }
  .conn-ok   { color: #4caf72; }
  .conn-down { color: #e25555; font-weight: 600; }

  /* Modal platnosci */
  #overlay {
    display: none; position: fixed; inset: 0; background: rgba(0,0,0,.7);
    align-items: center; justify-content: center; padding: 16px;
  }
  #modal {
    background: #1e2230; border-radius: 14px; padding: 24px; max-width: 360px; width: 100%;
    border: 1px solid #2c3142;
  }
  #modal h2 { margin: 0 0 4px; font-size: 18px; }
  #modal p  { color: #9aa0b4; font-size: 14px; margin: 4px 0; }
  .timer { font-size: 28px; font-weight: 700; text-align: center; margin: 14px 0; color: #ffb74d; }
  .btn {
    width: 100%; padding: 12px; border: none; border-radius: 8px; font-size: 15px;
    font-weight: 600; cursor: pointer; margin-top: 8px;
  }
  .btn-pay    { background: #2e7d46; color: #fff; }
  .btn-cancel { background: #3a3f4b; color: #cfd3df; }
  .msg { padding: 10px; border-radius: 8px; font-size: 14px; margin-top: 10px; display:none; }
  .msg-err { background: #4a1f1f; color: #ff9b9b; }
  .msg-ok  { background: #1f4a2c; color: #9bffb5; }
</style>
</head>
<body>
  <h1>🎬 Sala 1 — „Diuna: Część trzecia”</h1>
  <div class="sub">Bilet: 25 zł • wybierz wolne miejsce, aby zarezerwować</div>

  <div class="screen">E K R A N</div>
  <div id="grid" class="grid"></div>

  <div class="legend">
    <span><i class="dot free"></i> wolne</span>
    <span><i class="dot locked"></i> blokowane</span>
    <span><i class="dot sold"></i> sprzedane</span>
  </div>

  <div id="status">Łączenie…</div>

  <div id="overlay">
    <div id="modal">
      <h2>Płatność</h2>
      <p>Miejsce: <b id="m-seat"></b> • Kwota: <b id="m-amount"></b> zł</p>
      <p>Miejsce zablokowane. Dokończ płatność zanim minie czas:</p>
      <div class="timer" id="m-timer">10:00</div>
      <button class="btn btn-pay" id="btn-pay">Zapłać teraz</button>
      <button class="btn btn-cancel" id="btn-cancel">Anuluj</button>
      <div class="msg" id="m-msg"></div>
    </div>
  </div>

<script>
let ws, current = null, timerInt = null, myReservation = null;
const grid = document.getElementById('grid');
const statusEl = document.getElementById('status');

function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}/ws`);

  ws.onopen = () => {
    statusEl.textContent = '● Połączono — aktualizacja na żywo';
    statusEl.className = 'conn-ok';
  };
  ws.onmessage = (e) => {
    const data = JSON.parse(e.data);
    if (data.type === 'state') render(data.seats);
  };
  // Reakcja na awarie modulu rezerwacji -> komunikat + proba reconnectu
  ws.onclose = () => {
    statusEl.textContent = '✖ Utracono połączenie z serwerem rezerwacji — próba ponownego połączenia…';
    statusEl.className = 'conn-down';
    setTimeout(connect, 2000);
  };
  ws.onerror = () => { ws.close(); };
}

function render(seats) {
  const rows = {};
  seats.forEach(s => {
    const r = s.id[0];
    (rows[r] = rows[r] || []).push(s);
  });
  grid.innerHTML = '';
  Object.keys(rows).sort().forEach(r => {
    const rowDiv = document.createElement('div');
    rowDiv.className = 'row';
    const lab = document.createElement('div');
    lab.className = 'rowlabel'; lab.textContent = r;
    rowDiv.appendChild(lab);
    rows[r].sort((a,b)=>a.id.localeCompare(b.id)).forEach(s => {
      const b = document.createElement('button');
      b.className = 'seat ' + s.status;
      b.textContent = s.id.slice(1);
      if (s.status === 'locked' && s.remaining != null) {
        b.textContent = s.remaining + 's';
      }
      if (s.status === 'free') b.onclick = () => startReservation(s.id);
      rowDiv.appendChild(b);
    });
    grid.appendChild(rowDiv);
  });
}

async function startReservation(seatId) {
  // Krok 1: zablokuj miejsce
  let res;
  try {
    res = await fetch('/lock', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({seat_id: seatId})
    }).then(r => r.json());
  } catch (err) {
    alert('Brak połączenia z serwerem rezerwacji.');
    return;
  }
  if (!res.ok) { alert(res.error); return; }

  myReservation = res.reservation_id;
  openModal(seatId, res.amount, res.lock_seconds);
}

function openModal(seatId, amount, seconds) {
  document.getElementById('m-seat').textContent = seatId;
  document.getElementById('m-amount').textContent = amount;
  document.getElementById('m-msg').style.display = 'none';
  document.getElementById('btn-pay').disabled = false;
  document.getElementById('overlay').style.display = 'flex';

  let left = seconds;
  const tEl = document.getElementById('m-timer');
  const fmt = s => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
  tEl.textContent = fmt(left);
  clearInterval(timerInt);
  timerInt = setInterval(() => {
    left--;
    tEl.textContent = fmt(Math.max(0,left));
    if (left <= 0) {
      clearInterval(timerInt);
      showMsg('Czas minął — rezerwacja anulowana.', false);
      document.getElementById('btn-pay').disabled = true;
      releaseSeat();                 // zwolnij miejsce na serwerze od razu
      setTimeout(closeModal, 2500);
    }
  }, 1000);
}

// Zwalnia biezaca blokade na serwerze (anulowanie / wygasniecie w przegladarce).
// Nie czekamy na odpowiedz - to "best effort"; worker serwera i tak zwolni po czasie.
function releaseSeat() {
  if (!myReservation) return;
  const rid = myReservation;
  myReservation = null;            // od razu czyscimy, by uniknac podwojnego zwolnienia
  fetch('/release', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({reservation_id: rid})
  }).catch(() => {});              // brak polaczenia? worker serwera posprzata po 10 min
}

function closeModal() {
  document.getElementById('overlay').style.display = 'none';
  clearInterval(timerInt);
  myReservation = null;
}

function showMsg(text, ok) {
  const m = document.getElementById('m-msg');
  m.textContent = text;
  m.className = 'msg ' + (ok ? 'msg-ok' : 'msg-err');
  m.style.display = 'block';
}

// Anuluj: najpierw zwalniamy miejsce na serwerze, potem zamykamy okno.
document.getElementById('btn-cancel').onclick = () => {
  releaseSeat();
  closeModal();
};

document.getElementById('btn-pay').onclick = async () => {
  document.getElementById('btn-pay').disabled = true;
  showMsg('Przetwarzanie płatności…', true);
  let res;
  try {
    res = await fetch('/pay', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({reservation_id: myReservation})
    }).then(r => r.json());
  } catch (err) {
    showMsg('Brak połączenia z serwerem rezerwacji. Spróbuj ponownie.', false);
    document.getElementById('btn-pay').disabled = false;   // pozwol sprobowac ponownie
    return;
  }
  if (res.ok) {
    showMsg('✔ Płatność zaakceptowana! Transakcja: ' + res.transaction_id, true);
    clearInterval(timerInt);
    myReservation = null;            // sprzedane - nie zwalniamy przy zamknieciu
    setTimeout(closeModal, 2500);
  } else {
    showMsg('✖ ' + res.error, false);
    // platnosc odrzucona / rezerwacja wygasla -> serwer juz zwolnil miejsce
    myReservation = null;
    setTimeout(closeModal, 3000);
  }
};

// Zamkniecie karty/przegladarki podczas trwajacej blokady -> zwolnij miejsce.
// sendBeacon dziala nawet przy zamykaniu strony (zwykly fetch bywa anulowany).
window.addEventListener('beforeunload', () => {
  if (!myReservation) return;
  const blob = new Blob([JSON.stringify({reservation_id: myReservation})],
                        {type: 'application/json'});
  navigator.sendBeacon('/release', blob);
});

connect();
</script>
</body>
</html>
"""
