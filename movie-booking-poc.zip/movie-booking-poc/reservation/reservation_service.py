"""
RESERVATION SERVICE  (modul rezerwacji)
=======================================
Centralny modul systemu rezerwacji biletow kinowych (aplikacja konsolowa).

Odpowiada za:
  * przechowywanie stanu miejsc (wolne / zablokowane / sprzedane),
  * blokowanie miejsca na 10 minut przy przejsciu do platnosci,
  * automatyczne anulowanie rezerwacji, jesli platnosc nie nastapi w 10 min,
  * komunikacje real-time przez WebSocket (auto-odswiezanie kazdej przegladarki),
  * wywolanie modulu PLATNOSCI przez HTTP (z timeoutem) i obsluge jego awarii,
  * serwowanie prostego GUI (HTML) -> dziala na laptopie i telefonie.

Uruchomienie:   python reservation_service.py
Zmienne srodowiskowe:
    PAYMENT_URL   adres modulu platnosci (domyslnie http://localhost:4000)
    RES_PORT      port modulu rezerwacji  (domyslnie 3000)
    LOCK_SECONDS  czas blokady w sekundach (domyslnie 600 = 10 min)
"""

import os
import asyncio
import logging
import time
import uuid
from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from gui import HTML_PAGE

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [RESERV] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("reservation")

# --------------------------- KONFIGURACJA ----------------------------------
PAYMENT_URL = os.getenv("PAYMENT_URL", "http://localhost:4000")
LOCK_SECONDS = int(os.getenv("LOCK_SECONDS", "600"))   # 600 s = 10 minut
TICKET_PRICE = 25.0
PAYMENT_TIMEOUT = float(os.getenv("PAYMENT_TIMEOUT", "5"))

# --------------------------- STAN MIEJSC -----------------------------------
class Seat:
    def __init__(self, seat_id: str):
        self.id = seat_id
        self.status = "free"                 # free | locked | sold
        self.reservation_id: str | None = None
        self.locked_until: float | None = None

    def as_dict(self):
        remaining = None
        if self.status == "locked" and self.locked_until:
            remaining = max(0, int(self.locked_until - time.time()))
        return {"id": self.id, "status": self.status, "remaining": remaining}

ROWS = ["A", "B", "C", "D"]
COLS = range(1, 7)
SEATS: dict[str, Seat] = {f"{r}{c}": Seat(f"{r}{c}") for r in ROWS for c in COLS}
state_lock = asyncio.Lock()

# --------------------------- WEBSOCKET -------------------------------------
class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)
        log.info(f"Nowy klient WebSocket (lacznie {len(self.active)})")

    def disconnect(self, ws: WebSocket):
        if ws in self.active:
            self.active.remove(ws)
        log.info(f"Klient rozlaczony (lacznie {len(self.active)})")

    async def broadcast_state(self):
        payload = {"type": "state", "seats": [s.as_dict() for s in SEATS.values()]}
        dead = []
        for ws in self.active:
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

manager = ConnectionManager()

# ----------------- ZADANIE W TLE: auto-anulowanie blokad -------------------
async def expiry_worker():
    while True:
        await asyncio.sleep(1)
        now = time.time()
        async with state_lock:
            for seat in SEATS.values():
                if (seat.status == "locked" and seat.locked_until
                        and now >= seat.locked_until):
                    log.info(f"Blokada {seat.id} wygasla -> zwalniam (timeout 10 min)")
                    seat.status = "free"
                    seat.reservation_id = None
                    seat.locked_until = None
        await manager.broadcast_state()   # odswiezamy liczniki co sekunde

@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(expiry_worker())
    log.info("Worker auto-anulowania blokad wystartowal.")
    yield
    task.cancel()

app = FastAPI(title="Reservation Service", lifespan=lifespan)

# --------------------------- MODELE ----------------------------------------
class LockRequest(BaseModel):
    seat_id: str

class PayRequest(BaseModel):
    reservation_id: str

class ReleaseRequest(BaseModel):
    reservation_id: str

# --------------------------- ENDPOINTY -------------------------------------
@app.get("/health")
def health():
    return {"status": "ok", "service": "reservation"}

@app.post("/lock")
async def lock_seat(req: LockRequest):
    async with state_lock:
        seat = SEATS.get(req.seat_id)
        if not seat:
            return {"ok": False, "error": "Takie miejsce nie istnieje"}
        if seat.status == "sold":
            return {"ok": False, "error": "Miejsce juz sprzedane"}
        if seat.status == "locked":
            return {"ok": False, "error": "Miejsce wlasnie blokuje ktos inny"}
        seat.status = "locked"
        seat.reservation_id = str(uuid.uuid4())[:8]
        seat.locked_until = time.time() + LOCK_SECONDS
        rid = seat.reservation_id
        log.info(f"Miejsce {seat.id} ZABLOKOWANE na {LOCK_SECONDS}s (rezerwacja {rid})")
    await manager.broadcast_state()
    return {"ok": True, "reservation_id": rid, "amount": TICKET_PRICE,
            "lock_seconds": LOCK_SECONDS}

@app.post("/release")
async def release_seat(req: ReleaseRequest):
    """Recznie zwalnia zablokowane miejsce (np. po klinieciu 'Anuluj').
       Zwalnia tylko miejsca w stanie 'locked' - sprzedanych nie ruszamy."""
    async with state_lock:
        seat = next((s for s in SEATS.values()
                     if s.reservation_id == req.reservation_id), None)
        if not seat or seat.status != "locked":
            # nic do zwolnienia (juz wygaslo / sprzedane / nie istnieje) - to nie blad
            return {"ok": True}
        log.info(f"Miejsce {seat.id} ZWOLNIONE recznie (anulowanie, rezerwacja {seat.reservation_id})")
        seat.status = "free"
        seat.reservation_id = None
        seat.locked_until = None
    await manager.broadcast_state()
    return {"ok": True}


@app.post("/pay")
async def pay(req: PayRequest):
    seat = next((s for s in SEATS.values()
                 if s.reservation_id == req.reservation_id), None)
    if not seat or seat.status != "locked":
        return {"ok": False, "error": "Rezerwacja wygasla lub nie istnieje. "
                "Wybierz miejsce ponownie."}

    payload = {"reservation_id": seat.reservation_id, "seat": seat.id,
               "amount": TICKET_PRICE, "card_number": "4242"}

    # --- WYWOLANIE MIKROUSLUGI PLATNOSCI (HTTP, synchronicznie, z timeoutem) ---
    try:
        async with httpx.AsyncClient(timeout=PAYMENT_TIMEOUT) as client:
            resp = await client.post(f"{PAYMENT_URL}/pay", json=payload)
            resp.raise_for_status()
            data = resp.json()
    except httpx.TimeoutException:
        log.error("PLATNOSC: timeout - brak odpowiedzi.")
        return {"ok": False, "error": "Modul platnosci nie odpowiada (timeout). "
                "Sprobuj ponownie - miejsce pozostaje zablokowane."}
    except httpx.RequestError as e:
        log.error(f"PLATNOSC: brak polaczenia ({e}).")
        return {"ok": False, "error": "Modul platnosci jest niedostepny. "
                "Sprobuj pozniej - Twoja blokada miejsca jest wazna."}
    except Exception as e:
        log.error(f"PLATNOSC: nieoczekiwany blad ({e}).")
        return {"ok": False, "error": "Blad systemu platnosci."}

    if data.get("status") == "success":
        async with state_lock:
            seat.status = "sold"
            seat.locked_until = None
        log.info(f"Miejsce {seat.id} SPRZEDANE (tx {data.get('transaction_id')})")
        await manager.broadcast_state()
        return {"ok": True, "transaction_id": data.get("transaction_id")}
    else:
        async with state_lock:
            seat.status = "free"
            seat.reservation_id = None
            seat.locked_until = None
        log.warning(f"Miejsce {seat.id} zwolnione - platnosc odrzucona: {data.get('reason')}")
        await manager.broadcast_state()
        return {"ok": False, "error": f"Platnosc odrzucona: {data.get('reason')}"}

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    await ws.send_json({"type": "state", "seats": [s.as_dict() for s in SEATS.values()]})
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws)

@app.get("/", response_class=HTMLResponse)
def index():
    return HTML_PAGE

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("RES_PORT", "3000"))
    print("=" * 55)
    print("  RESERVATION SERVICE (modul rezerwacji)")
    print(f"  GUI / API:        http://0.0.0.0:{port}")
    print(f"  Modul platnosci:  {PAYMENT_URL}")
    print(f"  Czas blokady:     {LOCK_SECONDS}s")
    print("=" * 55)
    print(f"  Laptop:            http://localhost:{port}")
    print(f"  Telefon/inna masz: http://<IP-laptopa>:{port}")
    print("=" * 55)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")
