#!/usr/bin/env bash
# Uruchamia oba moduly (Linux/Mac). Kazdy zna adres drugiego (health-check w obie strony).
set -e
cd "$(dirname "$0")"
pip install -q -r requirements.txt

echo "Uruchamiam Payment Service (port 4000)..."
RESERVATION_URL=http://localhost:3000 python payment/payment_service.py &
PAYMENT_PID=$!
sleep 2
echo "Uruchamiam Reservation Service (port 3000)..."
PAYMENT_URL=http://localhost:4000 python reservation/reservation_service.py &
RES_PID=$!

echo ""
echo "================================================================"
echo "  System dziala!  Przegladarka:  http://localhost:3000"
echo "  Telefon (ta sama Wi-Fi):  http://<IP-tego-komputera>:3000"
echo "  IP:  hostname -I (Linux) / ipconfig getifaddr en0 (Mac)"
echo "  Zatrzymanie: Ctrl+C"
echo "================================================================"
trap "kill $PAYMENT_PID $RES_PID 2>/dev/null" EXIT
wait
